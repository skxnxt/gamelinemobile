const cors = require('cors');
const express = require('express');
const app = express();
const authRoute = require('./routes/auth');
const characterRoute = require('./routes/characters');
const monsterRoutes = require('./routes/monster');
const authMiddleware = require('./middleware/auth');
const sequelize = require('./config/database');
const path = require('path');

// Middleware to parse JSON request bodies
app.use(express.json());

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Routes to serve HTML pages
app.get('/game', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'game.html'));
});

app.get('/character', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'select-character.html'));
});

app.get('/create', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'create-character.html'));
});

// API routes protected with authentication middleware
app.use(cors());
app.use('/auth', authRoute);
app.use('/api', authMiddleware, characterRoute);
app.use('/api/monsters', monsterRoutes);

// Optional: Fallback route for unmatched paths (for client-side routing)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server after syncing the database
const PORT = process.env.PORT || 3000;
sequelize.sync().then(() => {
    app.listen(PORT, () => console.log(`Server running on http://192.168.1.8:${PORT}`));
});
