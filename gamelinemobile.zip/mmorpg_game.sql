/*
 Navicat Premium Data Transfer

 Source Server         : testgame
 Source Server Type    : MySQL
 Source Server Version : 100427 (10.4.27-MariaDB)
 Source Host           : localhost:3306
 Source Schema         : mmorpg_game

 Target Server Type    : MySQL
 Target Server Version : 100427 (10.4.27-MariaDB)
 File Encoding         : 65001

 Date: 16/10/2024 18:34:45
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for char_rarity
-- ----------------------------
DROP TABLE IF EXISTS `char_rarity`;
CREATE TABLE `char_rarity`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `rarity_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `item_frame_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of char_rarity
-- ----------------------------
INSERT INTO `char_rarity` VALUES (1, 'Common', NULL);
INSERT INTO `char_rarity` VALUES (2, 'Uncommon', NULL);
INSERT INTO `char_rarity` VALUES (3, 'Rare', NULL);
INSERT INTO `char_rarity` VALUES (4, 'Epic', NULL);
INSERT INTO `char_rarity` VALUES (5, 'Legendary', NULL);
INSERT INTO `char_rarity` VALUES (6, 'Godly', NULL);

-- ----------------------------
-- Table structure for char_type
-- ----------------------------
DROP TABLE IF EXISTS `char_type`;
CREATE TABLE `char_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `char_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `char_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `rarity` tinyint NULL DEFAULT 0,
  `effect_type_1` int NULL DEFAULT 0,
  `effect_value_1` int NULL DEFAULT 0,
  `effect_type_2` int NULL DEFAULT 0,
  `effect_value_2` int NULL DEFAULT 0,
  `effect_type_3` int NULL DEFAULT 0,
  `effect_value_3` int NULL DEFAULT 0,
  `effect_type_4` int NULL DEFAULT 0,
  `effect_value_4` int NULL DEFAULT 0,
  `effect_type_5` int NULL DEFAULT 0,
  `effect_value_5` int NULL DEFAULT 0,
  `can_create` int NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of char_type
-- ----------------------------
INSERT INTO `char_type` VALUES (1, 'Wolf', 'wolf.gif', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
INSERT INTO `char_type` VALUES (2, 'Fox', '2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
INSERT INTO `char_type` VALUES (3, 'Deer', '3', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);

-- ----------------------------
-- Table structure for character
-- ----------------------------
DROP TABLE IF EXISTS `character`;
CREATE TABLE `character`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `char_type` int NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `level` int NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `char_type`(`char_type` ASC) USING BTREE,
  CONSTRAINT `character_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `character_ibfk_2` FOREIGN KEY (`char_type`) REFERENCES `char_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of character
-- ----------------------------
INSERT INTO `character` VALUES (1, 11, 1, 'skxnxt', 1, '2024-10-15 21:58:37');
INSERT INTO `character` VALUES (2, 11, 1, 'Enasuma', 1, '2024-10-16 00:46:12');

-- ----------------------------
-- Table structure for item_rarity
-- ----------------------------
DROP TABLE IF EXISTS `item_rarity`;
CREATE TABLE `item_rarity`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `rarity_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `item_frame_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of item_rarity
-- ----------------------------
INSERT INTO `item_rarity` VALUES (1, 'Common', NULL);
INSERT INTO `item_rarity` VALUES (2, 'Uncommon', NULL);
INSERT INTO `item_rarity` VALUES (3, 'Rare', NULL);
INSERT INTO `item_rarity` VALUES (4, 'Epic', NULL);
INSERT INTO `item_rarity` VALUES (5, 'Legendary', NULL);
INSERT INTO `item_rarity` VALUES (6, 'Godly', NULL);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `line_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `line_id`(`line_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (11, 'Ud9002c03a3a4f5765d394fb6380d78b4', '2024-10-15 21:41:03');

SET FOREIGN_KEY_CHECKS = 1;
