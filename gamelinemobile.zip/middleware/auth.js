const jwt = require('jwt-simple');
require('dotenv').config();

module.exports = (req, res, next) => {
    const authHeader = req.headers['authorization'];  // Retrieve Authorization header

    if (!authHeader) {
        return res.status(403).send('Authorization header missing');
    }

    const token = authHeader.split(' ')[1];  // Extract the token from 'Bearer <token>'
    if (!token) {
        return res.status(403).send('Token missing');
    }

    try {
        const decoded = jwt.decode(token, process.env.JWT_SECRET);  // Decode the token
        req.user = decoded;  // Attach decoded user data to the request object
        next();  // Proceed to the next middleware/route
    } catch (error) {
        console.error('Invalid token:', error);
        res.status(403).send('Invalid token');
    }
};
